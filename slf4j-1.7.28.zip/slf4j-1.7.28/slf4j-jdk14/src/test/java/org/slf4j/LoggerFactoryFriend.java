package org.slf4j;

public class LoggerFactoryFriend {
    static public void reset() {
        LoggerFactory.reset();
    }
}
